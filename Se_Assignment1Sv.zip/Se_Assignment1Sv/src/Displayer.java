import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * @author Alessandro Corvi
 * @version 1
 */
public class Displayer {
    private static JFrame frame = new JFrame();
    private static JPanel panel;
    private static JFileChooser fileChooser;
    private static JMenuBar menuBar;



    public static void main(String[] args) throws IOException {

        QuadCurve2D c = new QuadCurve2D.Double();


        fileChooser = new JFileChooser("C:\\Users\\LAPTOP\\Desktop\\Se_Assignment1Sv\\Svgs");
        int returnValue = fileChooser.showOpenDialog(null);
        // int returnValue = jfc.showSaveDialog(null);

        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            FileAnalyzer fl = new FileAnalyzer(file);
            DataAnalyser dt = new DataAnalyser(fl.getData());
            ArrayList<ArrayList> in = dt.getOutput();

            for(ArrayList<Double> a : in)
            {
                System.out.println("id: " + a.get(0)
                        + " level: " + a.get(1)
                        + " coords: ");
                for(int i = 2; i < a.size(); i++)
                {
                    System.out.println(a.get(i));
                }
            }
            panel = new PanelBuilder(in);
            frame.add(panel);
        }




        frame.setVisible(true);
        frame.setSize(800,800);

    }

}
