import javax.swing.*;
import java.io.*;
import java.util.ArrayList;

public class FileAnalyzer {

    private static ArrayList<String> data = new ArrayList();

    public FileAnalyzer(File file) throws IOException {
        System.out.println("FILEANALIZER INITILAIALNFEI");
        FileReader rd = new FileReader(file);
        BufferedReader reader = new BufferedReader(rd);
        String s = "";
        String style = "<path style";
        while(!s.equals("</svg>"))
        {
            if(s.regionMatches(0,style,0,style.length())) break;
            s = reader.readLine();
        }
        System.out.println(s);
        String out = "";
        Boolean recording = false;
        for(int i = 0; i < s.length(); i++)
        {

            if(s.charAt(i) == 'd' && s.charAt(i+1) == '=' && s.charAt(i-1) == ' ' && !recording) {
                System.out.println("Recordin on");
                recording = true;
                i += 3;
            }
            else if(s.charAt(i) == '"' && recording) recording = false;

            if(recording) out += s.charAt(i);
        }
        System.out.println("\nAnal\n" + out);

        String[] datas = out.split(" ");

        System.out.println("\n");

        for (String ss:
             datas) {
            System.out.println(ss);
            data.add(ss);
        }

    }

    public static ArrayList<String> getData()
    {
        return data;
    }
}
