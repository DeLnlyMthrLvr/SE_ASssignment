import java.util.ArrayList;

public class DataAnalyser {
    private static ArrayList<String> data = new ArrayList();
    private static ArrayList<ArrayList> output = new ArrayList<>(); //the list is made of lists containing : (id, level, coords)
    private static final int MAGNIFIER = 5;
    /*
    ids:
    0 -> Q
    1 -> C

     */
    public DataAnalyser (ArrayList<String> data)
    {
        this.data = data;
        mainLoop();
    }

    public void mainLoop()
    {
        double x1 = 0.0;
        double y1 = 0.0;
        double level = 0.0;
     for(int i = 0; i < data.size(); i++)
     {
         switch (data.get(i).charAt(0))
         {
             case 'M':
                 String trimmed = data.get(i).substring(1);
                 x1 = Double.parseDouble(trimmed) ;
                 i++;
                 y1 = Double.parseDouble(data.get(i));
                 break;
             case 'Q':
                 output.add(q(x1,y1,level++,i));
                 x1 = Double.parseDouble(data.get(i +2));
                 y1 = Double.parseDouble(data.get(i +3));
                 break;
             case 'C':
                 output.add(c(x1,y1,level++,i));
                 x1 = Double.parseDouble(data.get(i +4));
                 y1 = Double.parseDouble(data.get(i +5));
                 break;
             case 'z':
                 if(data.get(i).length() <= 1)
                 {

                     x1 = 0.0;
                     y1 = 0.0;
                 }
                 else if(data.get(i).charAt(1) == 'M')
                 {
                     String trimmedd = data.get(i).substring(2);
                     x1 = Double.parseDouble(trimmedd) ;
                     i++;
                     y1 = Double.parseDouble(data.get(i));
                 }
                 break;
         }
     }
    }

    public static ArrayList<Double> q(double x1, double y1, double level, int index)
    {
        String trimmed = data.get(index).substring(1);
        double controlX = Double.parseDouble(trimmed);
        index++;
        double controlY = Double.parseDouble(data.get(index));
        index++;
        double endX = Double.parseDouble(data.get(index));
        index++;
        double endY = Double.parseDouble(data.get(index));
        ArrayList<Double> out = new ArrayList<>();

        out.add(0.0);
        out.add(level);
        out.add(x1 * MAGNIFIER);
        out.add(y1 * MAGNIFIER);
        out.add(controlX * MAGNIFIER);
        out.add(controlY * MAGNIFIER);
        out.add(endX * MAGNIFIER);
        out.add(endY * MAGNIFIER);

        return out;
    }

    public static ArrayList<Double> c(double x1, double y1, double level, int index)
    {
        String trimmed = data.get(index).substring(1);
        double controlX1 = Double.parseDouble(trimmed);
        index++;
        double controlY1 = Double.parseDouble(data.get(index));
        index++;
        double controlX2 = Double.parseDouble(data.get(index));
        index++;
        double controlY2 = Double.parseDouble(data.get(index));
        index++;
        double endX = Double.valueOf(data.get(index));
        index++;
        double endY = Double.valueOf(data.get(index));
        ArrayList<Double> out = new ArrayList<>();

        out.add(1.0);
        out.add(level);
        out.add(x1 * MAGNIFIER);
        out.add(y1 * MAGNIFIER);
        out.add(controlX1 * MAGNIFIER);
        out.add(controlY1 * MAGNIFIER);
        out.add(controlX2 * MAGNIFIER);
        out.add(controlY2 * MAGNIFIER);
        out.add(endX * MAGNIFIER);
        out.add(endY * MAGNIFIER);

        return out;
    }

    public static ArrayList<ArrayList> getOutput()
    {
        return output;
    }

}
