import javax.swing.*;
import java.awt.*;
import java.awt.geom.CubicCurve2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.QuadCurve2D;
import java.util.ArrayList;

public class PanelBuilder extends JPanel {
    ArrayList<ArrayList> data = new ArrayList<>();

    public PanelBuilder(ArrayList<ArrayList> data)
    {
        this.data = data;



    }

    @Override
    public void paint(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setPaint(Color.BLACK);
        for(ArrayList<Double> d :  data)
        {
            if(d.get(0)==0.0)
            {
                QuadCurve2D q = new QuadCurve2D.Double(d.get(2),d.get(3),d.get(4),d.get(5),d.get(6), d.get(7));
                g2.draw(q);
            }
            else if(d.get(0)==1.0)
            {
                CubicCurve2D c = new CubicCurve2D.Double(d.get(2),d.get(3),d.get(4),d.get(5),d.get(6), d.get(7),d.get(8), d.get(9));
                g2.draw(c);
            }
        }

    }
}
